import 'package:flutter/material.dart';

void main() => runApp(const MathYaarApp());

class MathYaarApp extends StatelessWidget {
  const MathYaarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ریاضی‌یار',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6558D3)),
        scaffoldBackgroundColor: const Color(0xFFF5F4FC),
      ),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomePage(),
      ),
    );
  }
}

class Question {
  final String text;
  final List<String> options;
  final int answer;
  final String explanation;
  const Question(this.text, this.options, this.answer, this.explanation);
}

class Chapter {
  final int number;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final String lesson;
  final List<Question> questions;
  const Chapter({
    required this.number,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.lesson,
    required this.questions,
  });
}

const chapters = <Chapter>[
  Chapter(number: 1, title: 'راهبردهای حل مسئله', subtitle: 'فکر کن، راه پیدا کن!', icon: Icons.lightbulb_rounded, color: Color(0xFFFFA94D),
    lesson: 'برای حل مسئله ابتدا صورت سؤال را با دقت بخوان. سپس داده‌ها و خواسته را مشخص کن. می‌توانی از رسم شکل، الگوسازی، حدس و آزمایش یا ساده‌کردن مسئله کمک بگیری.',
    questions: [
      Question('برای شروع حل یک مسئله، کدام کار مناسب‌تر است؟', ['حدس زدن پاسخ', 'خواندن دقیق و فهمیدن صورت مسئله', 'نوشتن پاسخ نهایی', 'حذف اطلاعات سؤال'], 1, 'ابتدا باید بدانیم مسئله چه اطلاعاتی دارد و چه چیزی می‌خواهد.'),
      Question('اگر مسئله پیچیده باشد، کدام راهبرد می‌تواند کمک کند؟', ['رسم شکل', 'نادیده گرفتن داده‌ها', 'عوض کردن سؤال', 'توقف حل مسئله'], 0, 'رسم شکل، اطلاعات مسئله را قابل مشاهده می‌کند.'),
    ]),
  Chapter(number: 2, title: 'عددهای صحیح', subtitle: 'دنیای مثبت‌ها و منفی‌ها', icon: Icons.exposure_rounded, color: Color(0xFF4E9DE6),
    lesson: 'عددهای صحیح شامل عددهای مثبت، عددهای منفی و صفر هستند. روی محور اعداد، هرچه به سمت راست برویم عدد بزرگ‌تر می‌شود. قرینهٔ هر عدد، عددی است که با آن جمع شود حاصل صفر شود.',
    questions: [
      Question('کدام عدد از همه بزرگ‌تر است؟', ['−۵', '−۱', '۰', '−۳'], 2, 'صفر از همه عددهای منفی بزرگ‌تر است.'),
      Question('حاصل  (−۴) + ۷  چند می‌شود؟', ['−۱۱', '−۳', '۳', '۱۱'], 2, 'از ۷ واحد، ۴ واحد کم می‌کنیم؛ حاصل ۳ است.'),
      Question('قرینهٔ عدد −۹ کدام است؟', ['−۹', '۰', '۹', '۱'], 2, 'قرینهٔ هر عدد، علامت مخالف آن را دارد.'),
    ]),
  Chapter(number: 3, title: 'جبر و معادله', subtitle: 'راز عددهای ناشناخته', icon: Icons.functions_rounded, color: Color(0xFF36B69A),
    lesson: 'در عبارت جبری از عدد و حرف استفاده می‌کنیم. حرفی مانند x می‌تواند نمایندهٔ یک عدد باشد. برای حل معادله، باید با انجام عملیات یکسان در دو طرف تساوی، مقدار مجهول را پیدا کنیم.',
    questions: [
      Question('اگر x + ۳ = ۸ باشد، x چند است؟', ['۳', '۵', '۸', '۱۱'], 1, 'با کم کردن ۳ از دو طرف، x برابر ۵ می‌شود.'),
      Question('در عبارت ۴a، عدد ۴ چه نام دارد؟', ['متغیر', 'ضریب', 'مجموع', 'مجهول'], 1, 'عددِ ضرب‌شده در متغیر را ضریب می‌نامیم.'),
    ]),
  Chapter(number: 4, title: 'هندسه و استدلال', subtitle: 'شکل‌ها را کشف کن', icon: Icons.category_rounded, color: Color(0xFF9B75D5),
    lesson: 'هندسه دربارهٔ شکل‌ها، خط‌ها، زاویه‌ها و ویژگی‌های آن‌هاست. مجموع زاویه‌های داخلی مثلث ۱۸۰ درجه است. زاویهٔ راست ۹۰ درجه اندازه دارد.',
    questions: [
      Question('مجموع زاویه‌های داخلی یک مثلث چند درجه است؟', ['۹۰', '۱۸۰', '۲۷۰', '۳۶۰'], 1, 'مجموع سه زاویهٔ داخلی هر مثلث ۱۸۰ درجه است.'),
      Question('اندازهٔ زاویهٔ راست چقدر است؟', ['۴۵ درجه', '۶۰ درجه', '۹۰ درجه', '۱۸۰ درجه'], 2, 'زاویهٔ راست برابر ۹۰ درجه است.'),
    ]),
  Chapter(number: 5, title: 'شمارنده‌ها و اعداد اول', subtitle: 'رازهای بخش‌پذیری', icon: Icons.numbers_rounded, color: Color(0xFFE56D8A),
    lesson: 'شمارندهٔ یک عدد، عددی است که آن را بدون باقی‌مانده تقسیم کند. عدد اول دقیقاً دو شمارندهٔ طبیعی دارد: ۱ و خودش. عدد ۱ اول نیست.',
    questions: [
      Question('کدام عدد اول است؟', ['۹', '۱۵', '۱۱', '۲۱'], 2, 'عدد ۱۱ فقط بر ۱ و ۱۱ بخش‌پذیر است.'),
      Question('عدد ۱ چند شمارندهٔ طبیعی دارد؟', ['۱', '۲', '۳', 'هیچ‌کدام'], 0, 'عدد ۱ فقط یک شمارندهٔ طبیعی، یعنی خودش، دارد.'),
    ]),
  Chapter(number: 6, title: 'سطح و حجم', subtitle: 'اندازه‌گیری در دنیای واقعی', icon: Icons.view_in_ar_rounded, color: Color(0xFF38A6B5),
    lesson: 'مساحت، اندازهٔ سطح یک شکل است و با واحدهای مربعی بیان می‌شود. حجم، فضای اشغال‌شده توسط یک جسم سه‌بعدی است. حجم مکعب‌مستطیل از ضرب طول، عرض و ارتفاع به دست می‌آید.',
    questions: [
      Question('مساحت مستطیل با طول ۵ و عرض ۳ چقدر است؟', ['۸', '۱۵', '۱۶', '۳۰'], 1, 'مساحت مستطیل برابر طول ضربدر عرض است: ۵ × ۳ = ۱۵.'),
      Question('حجم مکعب‌مستطیل چگونه محاسبه می‌شود؟', ['طول + عرض + ارتفاع', 'طول × عرض × ارتفاع', '۲ × طول', 'طول × عرض'], 1, 'برای حجم، سه بُعد را در هم ضرب می‌کنیم.'),
    ]),
  Chapter(number: 7, title: 'توان و جذر', subtitle: 'ضرب‌های تکراری', icon: Icons.bolt_rounded, color: Color(0xFFF0A43C),
    lesson: 'توان راه کوتاهی برای نشان دادن ضرب تکراری یک عدد در خودش است. مثلاً ۳ به توان ۲ یعنی ۳ × ۳ و برابر ۹ است. جذرِ ۹ عددی است که اگر در خودش ضرب شود ۹ به دست آید.',
    questions: [
      Question('۲ به توان ۳ برابر چند است؟', ['۶', '۸', '۹', '۱۲'], 1, '۲ به توان ۳ یعنی ۲ × ۲ × ۲ که برابر ۸ است.'),
      Question('جذرِ ۲۵ کدام است؟', ['۳', '۴', '۵', '۶'], 2, '۵ × ۵ برابر ۲۵ است؛ پس جذر ۲۵ برابر ۵ است.'),
    ]),
  Chapter(number: 8, title: 'بردار و مختصات', subtitle: 'مسیرها روی صفحه', icon: Icons.my_location_rounded, color: Color(0xFF6685D9),
    lesson: 'برای مشخص کردن جای یک نقطه روی صفحهٔ مختصات از یک زوج مرتب (x,y) استفاده می‌کنیم. ابتدا روی محور افقی حرکت می‌کنیم و سپس روی محور عمودی. بردار جهت و اندازهٔ جابه‌جایی را نشان می‌دهد.',
    questions: [
      Question('در زوج مرتب (۳،۲)، عدد اول نشان‌دهندهٔ چیست؟', ['مختصات افقی x', 'مختصات عمودی y', 'اندازهٔ زاویه', 'طول ضلع'], 0, 'در زوج مرتب (x,y)، مؤلفهٔ اول مختصات افقی است.'),
      Question('نقطهٔ (۰،۴) روی کدام محور قرار دارد؟', ['محور افقی', 'محور عمودی', 'مبدأ', 'هیچ محوری'], 1, 'وقتی x صفر باشد، نقطه روی محور عمودی قرار می‌گیرد.'),
    ]),
  Chapter(number: 9, title: 'آمار و احتمال', subtitle: 'از داده تا پیش‌بینی', icon: Icons.bar_chart_rounded, color: Color(0xFF45A879),
    lesson: 'آمار به جمع‌آوری و بررسی داده‌ها می‌پردازد. میانگین از تقسیم مجموع داده‌ها بر تعداد آن‌ها به دست می‌آید. احتمال، میزان شانس رخ دادن یک پیشامد را توصیف می‌کند.',
    questions: [
      Question('میانگین عددهای ۲، ۴ و ۶ چند است؟', ['۳', '۴', '۵', '۶'], 1, 'مجموع ۱۲ است و ۱۲ تقسیم بر ۳ برابر ۴ می‌شود.'),
      Question('هنگام پرتاب یک تاس سالم، احتمال آمدن عدد ۷ چقدر است؟', ['۱', '۱/۶', '۱/۲', '۰'], 3, 'روی تاس معمولی عدد ۷ وجود ندارد؛ پس این پیشامد غیرممکن است.'),
    ]),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int totalPoints = 0;
  int completed = 0;

  void openChapter(Chapter chapter) {
    Navigator.push(context, MaterialPageRoute(
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: ChapterPage(chapter: chapter, onFinished: (points) {
          setState(() {
            totalPoints += points;
            completed++;
          });
        }),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(
              child: Container(
                margin: const EdgeInsets.all(16),
                padding: const EdgeInsets.all(22),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF6558D3), Color(0xFF9279E8)], begin: Alignment.topRight, end: Alignment.bottomLeft),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [BoxShadow(color: const Color(0xFF6558D3).withOpacity(.22), blurRadius: 18, offset: const Offset(0, 8))],
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    const CircleAvatar(backgroundColor: Colors.white24, child: Icon(Icons.calculate_rounded, color: Colors.white)),
                    const SizedBox(width: 10),
                    const Expanded(child: Text('ریاضی‌یار', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold))),
                    _pill(Icons.stars_rounded, '$totalPoints امتیاز'),
                  ]),
                  const SizedBox(height: 24),
                  const Text('سلام قهرمان ریاضی! 👋', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('هر روز یک قدم به نابغه شدن نزدیک‌تر شو.', style: TextStyle(color: Colors.white70, fontSize: 13)),
                  const SizedBox(height: 20),
                  Row(children: [
                    Expanded(child: _stat('۹', 'فصل آموزشی', Icons.menu_book_rounded)),
                    const SizedBox(width: 10),
                    Expanded(child: _stat('$completed', 'آزمون انجام‌شده', Icons.emoji_events_rounded)),
                  ]),
                ]),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
                child: Row(children: [
                  const Expanded(child: Text('نقشهٔ ماجراجویی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                  Text('${chapters.length} مرحله', style: TextStyle(color: Colors.grey.shade600)),
                ]),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate((context, index) {
                  final c = chapters[index];
                  return InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () => openChapter(c),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), border: Border.all(color: c.color.withOpacity(.18)), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 10, offset: const Offset(0, 4))]),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Container(width: 44, height: 44, decoration: BoxDecoration(color: c.color.withOpacity(.14), borderRadius: BorderRadius.circular(14)), child: Icon(c.icon, color: c.color, size: 25)),
                        const Spacer(),
                        Text('مرحله ${c.number}', style: TextStyle(color: c.color, fontSize: 11, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(c.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(c.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
                      ]),
                    ),
                  );
                }, childCount: chapters.length),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.18),
              ),
            ),
            const SliverToBoxAdapter(child: Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Text('نسخهٔ آغازین پروژه • محتوای آموزشی داخل برنامه قرار دارد و برای اجرا به اینترنت نیاز نیست.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 11)),
            )),
          ],
        ),
      ),
    );
  }

  Widget _pill(IconData icon, String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(30)),
    child: Row(children: [Icon(icon, color: Colors.amberAccent, size: 17), const SizedBox(width: 5), Text(text, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold))]),
  );

  Widget _stat(String value, String label, IconData icon) => Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(16)),
    child: Row(children: [Icon(icon, color: Colors.white, size: 22), const SizedBox(width: 9), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10))])]),
  );
}

class ChapterPage extends StatefulWidget {
  final Chapter chapter;
  final ValueChanged<int> onFinished;
  const ChapterPage({super.key, required this.chapter, required this.onFinished});
  @override
  State<ChapterPage> createState() => _ChapterPageState();
}

class _ChapterPageState extends State<ChapterPage> {
  int index = 0;
  int score = 0;
  int? selected;
  bool answered = false;
  bool finished = false;

  void choose(int option) {
    if (answered) return;
    setState(() {
      selected = option;
      answered = true;
      if (option == widget.chapter.questions[index].answer) score += 10;
    });
  }

  void next() {
    if (index < widget.chapter.questions.length - 1) {
      setState(() { index++; selected = null; answered = false; });
    } else {
      setState(() => finished = true);
      widget.onFinished(score);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.chapter;
    return Scaffold(
      appBar: AppBar(title: Text('مرحله ${c.number}'), backgroundColor: Colors.transparent),
      body: SafeArea(child: finished ? _result() : ListView(padding: const EdgeInsets.all(18), children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(color: c.color.withOpacity(.12), borderRadius: BorderRadius.circular(24)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(c.icon, color: c.color, size: 34),
            const SizedBox(height: 12),
            Text(c.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('درس کوتاه', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(c.lesson, style: const TextStyle(height: 1.8)),
          ]),
        ),
        const SizedBox(height: 22),
        Row(children: [const Expanded(child: Text('چالش دانایی', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), Text('${index + 1} از ${c.questions.length}', style: TextStyle(color: Colors.grey.shade600))]),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: (index + 1) / c.questions.length, minHeight: 8, color: c.color, backgroundColor: c.color.withOpacity(.12))),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(c.questions[index].text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold, height: 1.6)),
            const SizedBox(height: 16),
            ...List.generate(c.questions[index].options.length, (i) {
              final isCorrect = i == c.questions[index].answer;
              final isSelected = selected == i;
              Color bg = Colors.white;
              Color border = Colors.grey.shade300;
              if (answered && isCorrect) { bg = const Color(0xFFE5F7ED); border = Colors.green; }
              else if (answered && isSelected) { bg = const Color(0xFFFFE8E8); border = Colors.redAccent; }
              return Padding(
                padding: const EdgeInsets.only(bottom: 9),
                child: InkWell(
                  onTap: () => choose(i),
                  borderRadius: BorderRadius.circular(14),
                  child: Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(color: bg, border: Border.all(color: border), borderRadius: BorderRadius.circular(14)),
                    child: Row(children: [
                      CircleAvatar(radius: 13, backgroundColor: c.color.withOpacity(.12), child: Text('${i + 1}', style: TextStyle(color: c.color, fontSize: 11, fontWeight: FontWeight.bold))),
                      const SizedBox(width: 10),
                      Expanded(child: Text(c.questions[index].options[i], style: const TextStyle(fontSize: 14))),
                      if (answered && isCorrect) const Icon(Icons.check_circle, color: Colors.green),
                      if (answered && isSelected && !isCorrect) const Icon(Icons.cancel, color: Colors.redAccent),
                    ]),
                  ),
                ),
              );
            }),
            if (answered) ...[
              const SizedBox(height: 8),
              Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFFF1F0FA), borderRadius: BorderRadius.circular(14)), child: Text('${selected == c.questions[index].answer ? 'آفرین! پاسخ درست بود 🎉' : 'اشکالی ندارد؛ با هم یاد می‌گیریم.'}\n${c.questions[index].explanation}', style: const TextStyle(height: 1.7))),
              const SizedBox(height: 12),
              FilledButton(onPressed: next, child: Text(index == c.questions.length - 1 ? 'دیدن نتیجه' : 'سؤال بعدی')),
            ],
          ]),
        ),
        const SizedBox(height: 12),
        Center(child: Text('امتیاز این مرحله: $score ⭐', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF6558D3)))),
      ])),
    );
  }

  Widget _result() => Center(
    child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.emoji_events_rounded, size: 86, color: Color(0xFFFFB547)),
        const SizedBox(height: 18),
        const Text('مرحله به پایان رسید!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text('امتیاز تو: $score از ${widget.chapter.questions.length * 10}', style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 8),
        const Text('آفرین قهرمان! برای یادگیری بیشتر دوباره تمرین کن.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.home_rounded), label: const Text('بازگشت به نقشه')),
      ]),
    ),
  );
}
